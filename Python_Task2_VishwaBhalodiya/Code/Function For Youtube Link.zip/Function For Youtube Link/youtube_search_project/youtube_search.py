import os
from googleapiclient.discovery import build
from dotenv import load_dotenv


load_dotenv()

def get_youtube_links(query, max_results=20):
   
    api_key = os.getenv("YOUTUBE_API_KEY")
    if not api_key:
        raise ValueError("YouTube API key not found. Set YOUTUBE_API_KEY in environment variables.")
    
    youtube = build("youtube", "v3", developerKey=api_key)
    
  
    request = youtube.search().list(
        q=query,
        part="snippet",
        type="video",
        maxResults=max_results
    )
    response = request.execute()

 
    videos = []
    for item in response["items"]:
        video_title = item["snippet"]["title"]
        video_id = item["id"]["videoId"]
        video_url = f"https://www.youtube.com/watch?v={video_id}"
        videos.append({"title": video_title, "url": video_url})

    return videos


if __name__ == "__main__":
    search_term = input("Enter your search query: ")
    results = get_youtube_links(search_term, max_results=20)

    print("\nTop YouTube Results:")
    for i, video in enumerate(results, start=1):
        print(f"{i}. {video['title']}")
        print(f"   🔗 {video['url']}\n")
